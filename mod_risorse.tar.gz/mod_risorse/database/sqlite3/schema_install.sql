-- mod_risorse database schema for SQLite3
-- CRM module: contatti, liste, campagne

-- Contatto: dati anagrafici e contatti
CREATE TABLE IF NOT EXISTS contatto (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cognome TEXT NOT NULL,
    email TEXT,
    telefono TEXT,
    stato INTEGER DEFAULT 0,
    consenso INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lista: insieme di contatti con consenso e stati
CREATE TABLE IF NOT EXISTS lista (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    descrizione TEXT,
    stato INTEGER DEFAULT 0,
    consenso INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Campagna: nome, validita, liste collegate
CREATE TABLE IF NOT EXISTS campagna (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    descrizione TEXT,
    data_inizio DATE,
    data_fine DATE,
    stato INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Relazione many-to-many: contatto <-> lista
CREATE TABLE IF NOT EXISTS contatto_lista (
    contatto_id INTEGER NOT NULL,
    lista_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (contatto_id, lista_id),
    FOREIGN KEY (contatto_id) REFERENCES contatto(id) ON DELETE CASCADE,
    FOREIGN KEY (lista_id) REFERENCES lista(id) ON DELETE CASCADE
);

-- Relazione many-to-many: lista <-> campagna
CREATE TABLE IF NOT EXISTS lista_campagna (
    lista_id INTEGER NOT NULL,
    campagna_id INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (lista_id, campagna_id),
    FOREIGN KEY (lista_id) REFERENCES lista(id) ON DELETE CASCADE,
    FOREIGN KEY (campagna_id) REFERENCES campagna(id) ON DELETE CASCADE
);

-- Indici per performance
CREATE INDEX IF NOT EXISTS idx_contatto_email ON contatto(email);
CREATE INDEX IF NOT EXISTS idx_contatto_stato ON contatto(stato);
CREATE INDEX IF NOT EXISTS idx_lista_stato ON lista(stato);
CREATE INDEX IF NOT EXISTS idx_campagna_stato ON campagna(stato);
CREATE INDEX IF NOT EXISTS idx_campagna_date ON campagna(data_inizio, data_fine);

-- Trigger per updated_at
CREATE TRIGGER IF NOT EXISTS update_contatto_timestamp
AFTER UPDATE ON contatto
BEGIN
    UPDATE contatto SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS update_lista_timestamp
AFTER UPDATE ON lista
BEGIN
    UPDATE lista SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS update_campagna_timestamp
AFTER UPDATE ON campagna
BEGIN
    UPDATE campagna SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;
