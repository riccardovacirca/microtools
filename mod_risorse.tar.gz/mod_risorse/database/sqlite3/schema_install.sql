-- Schema mod_risorse per SQLite3
-- Tabelle: contatti, liste, campagne + junction tables

-- Tabella contatti
CREATE TABLE IF NOT EXISTS contatti (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome VARCHAR(100) NOT NULL,
    cognome VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    indirizzo VARCHAR(255),
    citta VARCHAR(100),
    cap VARCHAR(10),
    provincia VARCHAR(50),
    nazione VARCHAR(50),
    consenso INTEGER NOT NULL DEFAULT 0,
    stato INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_contatti_email ON contatti(email);
CREATE INDEX IF NOT EXISTS idx_contatti_cognome_nome ON contatti(cognome, nome);
CREATE INDEX IF NOT EXISTS idx_contatti_stato ON contatti(stato);

-- Tabella liste
CREATE TABLE IF NOT EXISTS liste (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome VARCHAR(100) NOT NULL,
    descrizione VARCHAR(500),
    consenso_richiesto INTEGER NOT NULL DEFAULT 0,
    stato INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_liste_nome ON liste(nome);
CREATE INDEX IF NOT EXISTS idx_liste_stato ON liste(stato);

-- Tabella campagne
CREATE TABLE IF NOT EXISTS campagne (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome VARCHAR(100) NOT NULL,
    descrizione VARCHAR(500),
    data_inizio DATE NOT NULL,
    data_fine DATE,
    stato INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_campagne_nome ON campagne(nome);
CREATE INDEX IF NOT EXISTS idx_campagne_data_inizio ON campagne(data_inizio);
CREATE INDEX IF NOT EXISTS idx_campagne_stato ON campagne(stato);

-- Junction table: lista_contatti (N:M)
CREATE TABLE IF NOT EXISTS lista_contatti (
    lista_id INTEGER NOT NULL,
    contatto_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (lista_id, contatto_id),
    FOREIGN KEY (lista_id) REFERENCES liste(id) ON DELETE CASCADE,
    FOREIGN KEY (contatto_id) REFERENCES contatti(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_lista_contatti_lista ON lista_contatti(lista_id);
CREATE INDEX IF NOT EXISTS idx_lista_contatti_contatto ON lista_contatti(contatto_id);

-- Junction table: campagna_liste (N:M)
CREATE TABLE IF NOT EXISTS campagna_liste (
    campagna_id INTEGER NOT NULL,
    lista_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (campagna_id, lista_id),
    FOREIGN KEY (campagna_id) REFERENCES campagne(id) ON DELETE CASCADE,
    FOREIGN KEY (lista_id) REFERENCES liste(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_campagna_liste_campagna ON campagna_liste(campagna_id);
CREATE INDEX IF NOT EXISTS idx_campagna_liste_lista ON campagna_liste(lista_id);
