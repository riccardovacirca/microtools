-- Rimozione schema mod_risorse per SQLite3

DROP TABLE IF EXISTS campagna_liste;
DROP TABLE IF EXISTS lista_contatti;
DROP TABLE IF EXISTS campagne;
DROP TABLE IF EXISTS liste;
DROP TABLE IF EXISTS contatti;
