-- mod_risorse schema uninstall for SQLite3

DROP TRIGGER IF EXISTS update_campagna_timestamp;
DROP TRIGGER IF EXISTS update_lista_timestamp;
DROP TRIGGER IF EXISTS update_contatto_timestamp;

DROP INDEX IF EXISTS idx_campagna_date;
DROP INDEX IF EXISTS idx_campagna_stato;
DROP INDEX IF EXISTS idx_lista_stato;
DROP INDEX IF EXISTS idx_contatto_stato;
DROP INDEX IF EXISTS idx_contatto_email;

DROP TABLE IF EXISTS lista_campagna;
DROP TABLE IF EXISTS contatto_lista;
DROP TABLE IF EXISTS campagna;
DROP TABLE IF EXISTS lista;
DROP TABLE IF EXISTS contatto;
