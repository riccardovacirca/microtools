"""Adapters per mod_risorse."""
