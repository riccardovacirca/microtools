from pydantic import BaseModel, Field
from typing import Dict, Any

class ContattoModel(BaseModel):
    """Dati contatto."""
    id: int = Field(..., ge=1)
    nome: str = Field(..., min_length=1)
    cognome: str = Field(..., min_length=1)
    email: str | None = None
    telefono: str | None = None
    stato: int = Field(default=0, ge=0)
    consenso: int = Field(default=0, ge=0)
    created_at: str | None = None
    updated_at: str | None = None

    class Config:
        extra = "allow"

class ContattoCreateModel(BaseModel):
    """Dati per creazione contatto."""
    nome: str = Field(..., min_length=1)
    cognome: str = Field(..., min_length=1)
    email: str | None = None
    telefono: str | None = None
    stato: int = Field(default=0, ge=0)
    consenso: int = Field(default=0, ge=0)

class ContattoUpdateModel(BaseModel):
    """Dati per aggiornamento contatto."""
    nome: str | None = None
    cognome: str | None = None
    email: str | None = None
    telefono: str | None = None
    stato: int | None = None
    consenso: int | None = None

def get(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida e restituisce ContattoModel."""
    return ContattoModel(**data).model_dump()

def getCreate(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida dati creazione contatto."""
    return ContattoCreateModel(**data).model_dump()

def getUpdate(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida dati aggiornamento contatto."""
    return ContattoUpdateModel(**data).model_dump(exclude_none=True)
