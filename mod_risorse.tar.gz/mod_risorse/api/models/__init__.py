"""Models per mod_risorse."""
