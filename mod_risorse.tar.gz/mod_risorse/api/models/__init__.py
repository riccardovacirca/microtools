"""Models per mod_risorse."""
from . import ContattoModel
from . import ListaModel
from . import CampagnaModel
from . import ResponseModel
