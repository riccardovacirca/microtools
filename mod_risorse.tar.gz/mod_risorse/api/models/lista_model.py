"""Models Pydantic per entita Lista."""
from pydantic import BaseModel, Field
from typing import Any, List


# === Response ===

def response(err: bool, log: str | None, out: Any | None) -> dict:
    """Costruisce risposta standardizzata per lista.

    Args:
        err: True se errore, False se successo
        log: Messaggio errore se err=True, None se successo
        out: Dati se successo, None se errore

    Returns:
        dict: Risposta standardizzata con campi err, log, out
    """
    return {
        "err": err,
        "log": log,
        "out": out
    }


# === Input Models ===

class ListaInput(BaseModel):
    """Input model per creazione/aggiornamento lista."""
    nome: str = Field(..., min_length=1, max_length=100)
    descrizione: str | None = Field(None, max_length=500)
    consenso_richiesto: int = Field(..., ge=0, description="Bitwise flags per consenso richiesto ai contatti")
    stato: int = Field(0, ge=0, description="Bitwise flags per stato lista (es. 1=attiva, 2=pubblica, 4=archiviata)")


class ListaContattiInput(BaseModel):
    """Input model per aggiunta/rimozione contatti da lista."""
    contatto_ids: List[int] = Field(..., min_length=1)


# === Output Models ===

class ListaOutput(BaseModel):
    """Output model per lista."""
    id: int = Field(..., ge=1)
    nome: str = Field(..., min_length=1)
    descrizione: str | None
    consenso_richiesto: int = Field(..., ge=0)
    stato: int = Field(..., ge=0)
    contatti_count: int = Field(0, ge=0)
    created_at: str
    updated_at: str


class ListaListOutput(BaseModel):
    """Output model per elenco liste."""
    items: List[ListaOutput]
    total: int = Field(..., ge=0)
