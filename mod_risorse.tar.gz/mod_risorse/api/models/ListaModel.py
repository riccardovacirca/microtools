from pydantic import BaseModel, Field
from typing import Dict, Any

class ListaModel(BaseModel):
    """Dati lista."""
    id: int = Field(..., ge=1)
    nome: str = Field(..., min_length=1)
    descrizione: str | None = None
    stato: int = Field(default=0, ge=0)
    consenso: int = Field(default=0, ge=0)
    created_at: str | None = None
    updated_at: str | None = None

    class Config:
        extra = "allow"

class ListaCreateModel(BaseModel):
    """Dati per creazione lista."""
    nome: str = Field(..., min_length=1)
    descrizione: str | None = None
    stato: int = Field(default=0, ge=0)
    consenso: int = Field(default=0, ge=0)

class ListaUpdateModel(BaseModel):
    """Dati per aggiornamento lista."""
    nome: str | None = None
    descrizione: str | None = None
    stato: int | None = None
    consenso: int | None = None

def get(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida e restituisce ListaModel."""
    return ListaModel(**data).model_dump()

def getCreate(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida dati creazione lista."""
    return ListaCreateModel(**data).model_dump()

def getUpdate(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida dati aggiornamento lista."""
    return ListaUpdateModel(**data).model_dump(exclude_none=True)
