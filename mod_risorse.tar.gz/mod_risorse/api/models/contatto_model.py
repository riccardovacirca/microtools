"""Models Pydantic per entita Contatto."""
from pydantic import BaseModel, Field, EmailStr
from typing import Any, List


# === Response ===

def response(err: bool, log: str | None, out: Any | None) -> dict:
    """Costruisce risposta standardizzata per contatto.

    Args:
        err: True se errore, False se successo
        log: Messaggio errore se err=True, None se successo
        out: Dati se successo, None se errore

    Returns:
        dict: Risposta standardizzata con campi err, log, out
    """
    return {
        "err": err,
        "log": log,
        "out": out
    }


# === Input Models ===

class ContattoInput(BaseModel):
    """Input model per creazione/aggiornamento contatto."""
    nome: str = Field(..., min_length=1, max_length=100)
    cognome: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    telefono: str | None = Field(None, max_length=20)
    indirizzo: str | None = Field(None, max_length=255)
    citta: str | None = Field(None, max_length=100)
    cap: str | None = Field(None, max_length=10)
    provincia: str | None = Field(None, max_length=50)
    nazione: str | None = Field(None, max_length=50)
    consenso: int = Field(..., ge=0, description="Bitwise flags per consenso (es. 1=email, 2=sms, 4=telefono)")
    stato: int = Field(0, ge=0, description="Bitwise flags per stato (es. 1=attivo, 2=verificato, 4=bloccato)")


# === Output Models ===

class ContattoOutput(BaseModel):
    """Output model per contatto."""
    id: int = Field(..., ge=1)
    nome: str = Field(..., min_length=1)
    cognome: str = Field(..., min_length=1)
    email: str
    telefono: str | None
    indirizzo: str | None
    citta: str | None
    cap: str | None
    provincia: str | None
    nazione: str | None
    consenso: int = Field(..., ge=0)
    stato: int = Field(..., ge=0)
    created_at: str
    updated_at: str


class ContattoListOutput(BaseModel):
    """Output model per lista contatti."""
    items: List[ContattoOutput]
    total: int = Field(..., ge=0)
