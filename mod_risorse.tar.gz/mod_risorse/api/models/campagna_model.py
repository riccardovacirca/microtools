"""Models Pydantic per entita Campagna."""
from pydantic import BaseModel, Field
from typing import Any, List


# === Response ===

def response(err: bool, log: str | None, out: Any | None) -> dict:
    """Costruisce risposta standardizzata per campagna.

    Args:
        err: True se errore, False se successo
        log: Messaggio errore se err=True, None se successo
        out: Dati se successo, None se errore

    Returns:
        dict: Risposta standardizzata con campi err, log, out
    """
    return {
        "err": err,
        "log": log,
        "out": out
    }


# === Input Models ===

class CampagnaInput(BaseModel):
    """Input model per creazione/aggiornamento campagna."""
    nome: str = Field(..., min_length=1, max_length=100)
    descrizione: str | None = Field(None, max_length=500)
    data_inizio: str = Field(..., description="Data inizio validita (YYYY-MM-DD)")
    data_fine: str | None = Field(None, description="Data fine validita (YYYY-MM-DD), None se indefinita")
    stato: int = Field(0, ge=0, description="Bitwise flags per stato (es. 1=attiva, 2=in_pausa, 4=completata)")


class CampagnaListeInput(BaseModel):
    """Input model per collegamento/scollegamento liste a campagna."""
    lista_ids: List[int] = Field(..., min_length=1)


# === Output Models ===

class CampagnaOutput(BaseModel):
    """Output model per campagna."""
    id: int = Field(..., ge=1)
    nome: str = Field(..., min_length=1)
    descrizione: str | None
    data_inizio: str
    data_fine: str | None
    stato: int = Field(..., ge=0)
    liste_count: int = Field(0, ge=0)
    created_at: str
    updated_at: str


class CampagnaListOutput(BaseModel):
    """Output model per elenco campagne."""
    items: List[CampagnaOutput]
    total: int = Field(..., ge=0)
