from pydantic import BaseModel, Field
from typing import Dict, Any

class CampagnaModel(BaseModel):
    """Dati campagna."""
    id: int = Field(..., ge=1)
    nome: str = Field(..., min_length=1)
    descrizione: str | None = None
    data_inizio: str | None = None
    data_fine: str | None = None
    stato: int = Field(default=0, ge=0)
    created_at: str | None = None
    updated_at: str | None = None

    class Config:
        extra = "allow"

def get(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida e restituisce CampagnaModel."""
    return CampagnaModel(**data).model_dump()

class CampagnaCreateModel(BaseModel):
    """Dati per creazione campagna."""
    nome: str = Field(..., min_length=1)
    descrizione: str | None = None
    data_inizio: str | None = None
    data_fine: str | None = None
    stato: int = Field(default=0, ge=0)

def getCreate(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida dati creazione campagna."""
    return CampagnaCreateModel(**data).model_dump()

class CampagnaUpdateModel(BaseModel):
    """Dati per aggiornamento campagna."""
    nome: str | None = None
    descrizione: str | None = None
    data_inizio: str | None = None
    data_fine: str | None = None
    stato: int | None = None

def getUpdate(data: Dict[str, Any]) -> Dict[str, Any]:
    """Valida dati aggiornamento campagna."""
    return CampagnaUpdateModel(**data).model_dump(exclude_none=True)
