"""Repository per entita Campagna."""
from api.utils.DB import DB, Record, Recordset


def select(db: DB, id: int) -> Record:
    """Select campagna by ID with liste count."""
    sql = """
        SELECT c.id, c.nome, c.descrizione, c.data_inizio, c.data_fine, c.stato,
               c.created_at, c.updated_at,
               (SELECT COUNT(*) FROM campagna_liste WHERE campagna_id = c.id) as liste_count
        FROM campagne c
        WHERE c.id = ?
    """
    return db.select(sql, (id,))


def select_all(db: DB) -> Recordset:
    """Select all campagne with liste count."""
    sql = """
        SELECT c.id, c.nome, c.descrizione, c.data_inizio, c.data_fine, c.stato,
               c.created_at, c.updated_at,
               (SELECT COUNT(*) FROM campagna_liste WHERE campagna_id = c.id) as liste_count
        FROM campagne c
        ORDER BY c.data_inizio DESC
    """
    return db.select_all(sql)


def insert(db: DB, data: dict) -> int:
    """Insert campagna and return ID."""
    sql = """
        INSERT INTO campagne (nome, descrizione, data_inizio, data_fine, stato)
        VALUES (?, ?, ?, ?, ?)
    """
    return db.insert(sql, (
        data["nome"], data.get("descrizione"), data["data_inizio"],
        data.get("data_fine"), data.get("stato", 0)
    ))


def update(db: DB, id: int, data: dict) -> int:
    """Update campagna and return affected rows."""
    sql = """
        UPDATE campagne
        SET nome = ?, descrizione = ?, data_inizio = ?, data_fine = ?, stato = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """
    return db.query(sql, (
        data["nome"], data.get("descrizione"), data["data_inizio"],
        data.get("data_fine"), data.get("stato", 0), id
    ))


def delete(db: DB, id: int) -> int:
    """Delete campagna and return affected rows."""
    sql = "DELETE FROM campagne WHERE id = ?"
    return db.query(sql, (id,))


# === Junction table: campagna_liste ===

def add_liste(db: DB, campagna_id: int, lista_ids: list) -> int:
    """Add multiple liste to campagna."""
    sql = "INSERT OR IGNORE INTO campagna_liste (campagna_id, lista_id) VALUES (?, ?)"
    count = 0
    for lista_id in lista_ids:
        count += db.insert(sql, (campagna_id, lista_id))
    return count


def remove_liste(db: DB, campagna_id: int, lista_ids: list) -> int:
    """Remove multiple liste from campagna."""
    placeholders = ",".join(["?" for _ in lista_ids])
    sql = f"DELETE FROM campagna_liste WHERE campagna_id = ? AND lista_id IN ({placeholders})"
    return db.query(sql, (campagna_id, *lista_ids))
