from typing import Dict, List, Any
from ...utils.DB import DB

def getAll(db: DB) -> List[Dict[str, Any]]:
    """Recupera tutte le liste."""
    sql = """
        SELECT id, nome, descrizione, stato, consenso, created_at, updated_at
        FROM lista
        ORDER BY nome
    """
    retv = db.select(sql)
    return retv

def getById(db: DB, id: int) -> Dict[str, Any]:
    """Recupera lista per id."""
    sql = """
        SELECT id, nome, descrizione, stato, consenso, created_at, updated_at
        FROM lista
        WHERE id = ?
    """
    rows = db.select(sql, (id,))
    retv = {}
    if len(rows) > 0:
        retv = rows[0]
    return retv

def getByCampagna(db: DB, campagnaId: int) -> List[Dict[str, Any]]:
    """Recupera liste per campagna."""
    sql = """
        SELECT l.id, l.nome, l.descrizione, l.stato, l.consenso, l.created_at, l.updated_at
        FROM lista l
        INNER JOIN lista_campagna lc ON l.id = lc.lista_id
        WHERE lc.campagna_id = ?
        ORDER BY l.nome
    """
    retv = db.select(sql, (campagnaId,))
    return retv

def create(db: DB, data: Dict[str, Any]) -> int | None:
    """Crea nuova lista."""
    sql = """
        INSERT INTO lista (nome, descrizione, stato, consenso)
        VALUES (?, ?, ?, ?)
    """
    params = (
        data.get("nome"),
        data.get("descrizione"),
        data.get("stato", 0),
        data.get("consenso", 0)
    )
    retv = db.query(sql, params)
    return retv

def update(db: DB, id: int, data: Dict[str, Any]) -> int | None:
    """Aggiorna lista esistente."""
    fields = []
    params = []
    for key in data:
        fields.append(key + " = ?")
        params.append(data[key])
    retv = 0
    if len(fields) > 0:
        params.append(id)
        sql = "UPDATE lista SET " + ", ".join(fields) + " WHERE id = ?"
        retv = db.query(sql, tuple(params))
    return retv

def delete(db: DB, id: int) -> int | None:
    """Elimina lista."""
    sql = "DELETE FROM lista WHERE id = ?"
    retv = db.query(sql, (id,))
    return retv

def addToCampagna(db: DB, listaId: int, campagnaId: int) -> int | None:
    """Aggiunge lista a campagna."""
    sql = "INSERT OR IGNORE INTO lista_campagna (lista_id, campagna_id) VALUES (?, ?)"
    retv = db.query(sql, (listaId, campagnaId))
    return retv

def removeFromCampagna(db: DB, listaId: int, campagnaId: int) -> int | None:
    """Rimuove lista da campagna."""
    sql = "DELETE FROM lista_campagna WHERE lista_id = ? AND campagna_id = ?"
    retv = db.query(sql, (listaId, campagnaId))
    return retv

def getCampagne(db: DB, listaId: int) -> List[Dict[str, Any]]:
    """Recupera campagne di una lista."""
    sql = """
        SELECT c.id, c.nome, c.descrizione, c.data_inizio, c.data_fine, c.stato, c.created_at, c.updated_at
        FROM campagna c
        INNER JOIN lista_campagna lc ON c.id = lc.campagna_id
        WHERE lc.lista_id = ?
        ORDER BY c.nome
    """
    retv = db.select(sql, (listaId,))
    return retv

def getContatti(db: DB, listaId: int) -> List[Dict[str, Any]]:
    """Recupera contatti di una lista."""
    sql = """
        SELECT c.id, c.nome, c.cognome, c.email, c.telefono, c.stato, c.consenso, c.created_at, c.updated_at
        FROM contatto c
        INNER JOIN contatto_lista cl ON c.id = cl.contatto_id
        WHERE cl.lista_id = ?
        ORDER BY c.cognome, c.nome
    """
    retv = db.select(sql, (listaId,))
    return retv

def countContatti(db: DB, listaId: int) -> int:
    """Conta contatti in una lista."""
    sql = "SELECT COUNT(*) as cnt FROM contatto_lista WHERE lista_id = ?"
    rows = db.select(sql, (listaId,))
    retv = 0
    if len(rows) > 0:
        retv = rows[0].get("cnt", 0)
    return retv
