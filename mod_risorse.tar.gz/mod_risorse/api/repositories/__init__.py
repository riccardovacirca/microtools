"""Repositories per mod_risorse."""
