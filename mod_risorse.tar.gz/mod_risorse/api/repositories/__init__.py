"""Repositories per mod_risorse."""
from . import ContattoRepository
from . import ListaRepository
from . import CampagnaRepository
