"""Repository per entita Contatto."""
from api.utils.DB import DB, Record, Recordset


def select(db: DB, id: int) -> Record:
    """Select contatto by ID."""
    sql = """
        SELECT id, nome, cognome, email, telefono, indirizzo, citta, cap,
               provincia, nazione, consenso, stato, created_at, updated_at
        FROM contatti
        WHERE id = ?
    """
    return db.select(sql, (id,))


def select_all(db: DB) -> Recordset:
    """Select all contatti."""
    sql = """
        SELECT id, nome, cognome, email, telefono, indirizzo, citta, cap,
               provincia, nazione, consenso, stato, created_at, updated_at
        FROM contatti
        ORDER BY cognome, nome
    """
    return db.select_all(sql)


def select_by_lista(db: DB, lista_id: int) -> Recordset:
    """Select contatti by lista ID."""
    sql = """
        SELECT c.id, c.nome, c.cognome, c.email, c.telefono, c.indirizzo,
               c.citta, c.cap, c.provincia, c.nazione, c.consenso, c.stato,
               c.created_at, c.updated_at
        FROM contatti c
        INNER JOIN lista_contatti lc ON c.id = lc.contatto_id
        WHERE lc.lista_id = ?
        ORDER BY c.cognome, c.nome
    """
    return db.select_all(sql, (lista_id,))


def insert(db: DB, data: dict) -> int:
    """Insert contatto and return ID."""
    sql = """
        INSERT INTO contatti (nome, cognome, email, telefono, indirizzo,
                              citta, cap, provincia, nazione, consenso, stato)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    return db.insert(sql, (
        data["nome"], data["cognome"], data["email"], data.get("telefono"),
        data.get("indirizzo"), data.get("citta"), data.get("cap"),
        data.get("provincia"), data.get("nazione"), data["consenso"],
        data.get("stato", 0)
    ))


def update(db: DB, id: int, data: dict) -> int:
    """Update contatto and return affected rows."""
    sql = """
        UPDATE contatti
        SET nome = ?, cognome = ?, email = ?, telefono = ?, indirizzo = ?,
            citta = ?, cap = ?, provincia = ?, nazione = ?, consenso = ?,
            stato = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """
    return db.query(sql, (
        data["nome"], data["cognome"], data["email"], data.get("telefono"),
        data.get("indirizzo"), data.get("citta"), data.get("cap"),
        data.get("provincia"), data.get("nazione"), data["consenso"],
        data.get("stato", 0), id
    ))


def delete(db: DB, id: int) -> int:
    """Delete contatto and return affected rows."""
    sql = "DELETE FROM contatti WHERE id = ?"
    return db.query(sql, (id,))
