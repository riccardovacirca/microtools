from typing import Dict, List, Any
from ...utils.DB import DB

def getAll(db: DB) -> List[Dict[str, Any]]:
    """Recupera tutte le campagne."""
    sql = """
        SELECT id, nome, descrizione, data_inizio, data_fine, stato, created_at, updated_at
        FROM campagna
        ORDER BY data_inizio DESC, nome
    """
    retv = db.select(sql)
    return retv

def getById(db: DB, id: int) -> Dict[str, Any]:
    """Recupera campagna per id."""
    sql = """
        SELECT id, nome, descrizione, data_inizio, data_fine, stato, created_at, updated_at
        FROM campagna
        WHERE id = ?
    """
    rows = db.select(sql, (id,))
    retv = {}
    if len(rows) > 0:
        retv = rows[0]
    return retv

def getActive(db: DB) -> List[Dict[str, Any]]:
    """Recupera campagne attive (data corrente tra inizio e fine)."""
    sql = """
        SELECT id, nome, descrizione, data_inizio, data_fine, stato, created_at, updated_at
        FROM campagna
        WHERE (data_inizio IS NULL OR data_inizio <= date('now'))
        AND (data_fine IS NULL OR data_fine >= date('now'))
        ORDER BY data_inizio DESC, nome
    """
    retv = db.select(sql)
    return retv

def create(db: DB, data: Dict[str, Any]) -> int | None:
    """Crea nuova campagna."""
    sql = """
        INSERT INTO campagna (nome, descrizione, data_inizio, data_fine, stato)
        VALUES (?, ?, ?, ?, ?)
    """
    params = (
        data.get("nome"),
        data.get("descrizione"),
        data.get("data_inizio"),
        data.get("data_fine"),
        data.get("stato", 0)
    )
    retv = db.query(sql, params)
    return retv

def update(db: DB, id: int, data: Dict[str, Any]) -> int | None:
    """Aggiorna campagna esistente."""
    fields = []
    params = []
    for key in data:
        fields.append(key + " = ?")
        params.append(data[key])
    retv = 0
    if len(fields) > 0:
        params.append(id)
        sql = "UPDATE campagna SET " + ", ".join(fields) + " WHERE id = ?"
        retv = db.query(sql, tuple(params))
    return retv

def delete(db: DB, id: int) -> int | None:
    """Elimina campagna."""
    sql = "DELETE FROM campagna WHERE id = ?"
    retv = db.query(sql, (id,))
    return retv

def getListe(db: DB, campagnaId: int) -> List[Dict[str, Any]]:
    """Recupera liste di una campagna."""
    sql = """
        SELECT l.id, l.nome, l.descrizione, l.stato, l.consenso, l.created_at, l.updated_at
        FROM lista l
        INNER JOIN lista_campagna lc ON l.id = lc.lista_id
        WHERE lc.campagna_id = ?
        ORDER BY l.nome
    """
    retv = db.select(sql, (campagnaId,))
    return retv

def addLista(db: DB, campagnaId: int, listaId: int) -> int | None:
    """Aggiunge lista a campagna."""
    sql = "INSERT OR IGNORE INTO lista_campagna (lista_id, campagna_id) VALUES (?, ?)"
    retv = db.query(sql, (listaId, campagnaId))
    return retv

def removeLista(db: DB, campagnaId: int, listaId: int) -> int | None:
    """Rimuove lista da campagna."""
    sql = "DELETE FROM lista_campagna WHERE lista_id = ? AND campagna_id = ?"
    retv = db.query(sql, (listaId, campagnaId))
    return retv

def countContatti(db: DB, campagnaId: int) -> int:
    """Conta contatti totali in una campagna (via liste)."""
    sql = """
        SELECT COUNT(DISTINCT cl.contatto_id) as cnt
        FROM contatto_lista cl
        INNER JOIN lista_campagna lc ON cl.lista_id = lc.lista_id
        WHERE lc.campagna_id = ?
    """
    rows = db.select(sql, (campagnaId,))
    retv = 0
    if len(rows) > 0:
        retv = rows[0].get("cnt", 0)
    return retv
