"""Repository per entita Lista."""
from api.utils.DB import DB, Record, Recordset


def select(db: DB, id: int) -> Record:
    """Select lista by ID with contatti count."""
    sql = """
        SELECT l.id, l.nome, l.descrizione, l.consenso_richiesto, l.stato,
               l.created_at, l.updated_at,
               (SELECT COUNT(*) FROM lista_contatti WHERE lista_id = l.id) as contatti_count
        FROM liste l
        WHERE l.id = ?
    """
    return db.select(sql, (id,))


def select_all(db: DB) -> Recordset:
    """Select all liste with contatti count."""
    sql = """
        SELECT l.id, l.nome, l.descrizione, l.consenso_richiesto, l.stato,
               l.created_at, l.updated_at,
               (SELECT COUNT(*) FROM lista_contatti WHERE lista_id = l.id) as contatti_count
        FROM liste l
        ORDER BY l.nome
    """
    return db.select_all(sql)


def select_by_campagna(db: DB, campagna_id: int) -> Recordset:
    """Select liste by campagna ID."""
    sql = """
        SELECT l.id, l.nome, l.descrizione, l.consenso_richiesto, l.stato,
               l.created_at, l.updated_at,
               (SELECT COUNT(*) FROM lista_contatti WHERE lista_id = l.id) as contatti_count
        FROM liste l
        INNER JOIN campagna_liste cl ON l.id = cl.lista_id
        WHERE cl.campagna_id = ?
        ORDER BY l.nome
    """
    return db.select_all(sql, (campagna_id,))


def insert(db: DB, data: dict) -> int:
    """Insert lista and return ID."""
    sql = """
        INSERT INTO liste (nome, descrizione, consenso_richiesto, stato)
        VALUES (?, ?, ?, ?)
    """
    return db.insert(sql, (
        data["nome"], data.get("descrizione"), data["consenso_richiesto"],
        data.get("stato", 0)
    ))


def update(db: DB, id: int, data: dict) -> int:
    """Update lista and return affected rows."""
    sql = """
        UPDATE liste
        SET nome = ?, descrizione = ?, consenso_richiesto = ?, stato = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """
    return db.query(sql, (
        data["nome"], data.get("descrizione"), data["consenso_richiesto"],
        data.get("stato", 0), id
    ))


def delete(db: DB, id: int) -> int:
    """Delete lista and return affected rows."""
    sql = "DELETE FROM liste WHERE id = ?"
    return db.query(sql, (id,))


# === Junction table: lista_contatti ===

def add_contatti(db: DB, lista_id: int, contatto_ids: list) -> int:
    """Add multiple contatti to lista."""
    sql = "INSERT OR IGNORE INTO lista_contatti (lista_id, contatto_id) VALUES (?, ?)"
    count = 0
    for contatto_id in contatto_ids:
        count += db.insert(sql, (lista_id, contatto_id))
    return count


def remove_contatti(db: DB, lista_id: int, contatto_ids: list) -> int:
    """Remove multiple contatti from lista."""
    placeholders = ",".join(["?" for _ in contatto_ids])
    sql = f"DELETE FROM lista_contatti WHERE lista_id = ? AND contatto_id IN ({placeholders})"
    return db.query(sql, (lista_id, *contatto_ids))
