from typing import Dict, List, Any
from ...utils.DB import DB

def getAll(db: DB) -> List[Dict[str, Any]]:
    """Recupera tutti i contatti."""
    sql = """
        SELECT id, nome, cognome, email, telefono, stato, consenso, created_at, updated_at
        FROM contatto
        ORDER BY cognome, nome
    """
    retv = db.select(sql)
    return retv

def getById(db: DB, id: int) -> Dict[str, Any]:
    """Recupera contatto per id."""
    sql = """
        SELECT id, nome, cognome, email, telefono, stato, consenso, created_at, updated_at
        FROM contatto
        WHERE id = ?
    """
    rows = db.select(sql, (id,))
    retv = {}
    if len(rows) > 0:
        retv = rows[0]
    return retv

def getByEmail(db: DB, email: str) -> Dict[str, Any]:
    """Recupera contatto per email."""
    sql = """
        SELECT id, nome, cognome, email, telefono, stato, consenso, created_at, updated_at
        FROM contatto
        WHERE email = ?
    """
    rows = db.select(sql, (email,))
    retv = {}
    if len(rows) > 0:
        retv = rows[0]
    return retv

def getByLista(db: DB, listaId: int) -> List[Dict[str, Any]]:
    """Recupera contatti per lista."""
    sql = """
        SELECT c.id, c.nome, c.cognome, c.email, c.telefono, c.stato, c.consenso, c.created_at, c.updated_at
        FROM contatto c
        INNER JOIN contatto_lista cl ON c.id = cl.contatto_id
        WHERE cl.lista_id = ?
        ORDER BY c.cognome, c.nome
    """
    retv = db.select(sql, (listaId,))
    return retv

def create(db: DB, data: Dict[str, Any]) -> int | None:
    """Crea nuovo contatto."""
    sql = """
        INSERT INTO contatto (nome, cognome, email, telefono, stato, consenso)
        VALUES (?, ?, ?, ?, ?, ?)
    """
    params = (
        data.get("nome"),
        data.get("cognome"),
        data.get("email"),
        data.get("telefono"),
        data.get("stato", 0),
        data.get("consenso", 0)
    )
    retv = db.query(sql, params)
    return retv

def update(db: DB, id: int, data: Dict[str, Any]) -> int | None:
    """Aggiorna contatto esistente."""
    fields = []
    params = []
    for key in data:
        fields.append(key + " = ?")
        params.append(data[key])
    retv = 0
    if len(fields) > 0:
        params.append(id)
        sql = "UPDATE contatto SET " + ", ".join(fields) + " WHERE id = ?"
        retv = db.query(sql, tuple(params))
    return retv

def delete(db: DB, id: int) -> int | None:
    """Elimina contatto."""
    sql = "DELETE FROM contatto WHERE id = ?"
    retv = db.query(sql, (id,))
    return retv

def addToLista(db: DB, contattoId: int, listaId: int) -> int | None:
    """Aggiunge contatto a lista."""
    sql = "INSERT OR IGNORE INTO contatto_lista (contatto_id, lista_id) VALUES (?, ?)"
    retv = db.query(sql, (contattoId, listaId))
    return retv

def removeFromLista(db: DB, contattoId: int, listaId: int) -> int | None:
    """Rimuove contatto da lista."""
    sql = "DELETE FROM contatto_lista WHERE contatto_id = ? AND lista_id = ?"
    retv = db.query(sql, (contattoId, listaId))
    return retv

def getListe(db: DB, contattoId: int) -> List[Dict[str, Any]]:
    """Recupera liste di un contatto."""
    sql = """
        SELECT l.id, l.nome, l.descrizione, l.stato, l.consenso, l.created_at, l.updated_at
        FROM lista l
        INNER JOIN contatto_lista cl ON l.id = cl.lista_id
        WHERE cl.contatto_id = ?
        ORDER BY l.nome
    """
    retv = db.select(sql, (contattoId,))
    return retv
