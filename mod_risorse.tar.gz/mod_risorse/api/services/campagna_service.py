"""Service per entita Campagna."""
from typing import Dict, Any, List
from api.utils.DB import DB
from api.utils.DBConnPool import DBConnPool
from ..models import campagna_model, lista_model
from ..repositories import campagna_repository, lista_repository


async def get_all(pool: DBConnPool) -> dict:
    """Recupera tutte le campagne."""
    db = DB()
    try:
        db.acquire(pool)
        rows = campagna_repository.select_all(db)
        items = [dict(row) for row in rows]
        output = campagna_model.CampagnaListOutput(items=items, total=len(items))
        return campagna_model.response(False, None, output.model_dump())
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()


async def get(pool: DBConnPool, id: int) -> dict:
    """Recupera campagna by ID."""
    db = DB()
    try:
        db.acquire(pool)
        row = campagna_repository.select(db, id)
        if not row:
            return campagna_model.response(True, "Campagna non trovata", None)
        output = campagna_model.CampagnaOutput(**dict(row))
        return campagna_model.response(False, None, output.model_dump())
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()


async def create(pool: DBConnPool, data: Dict[str, Any]) -> dict:
    """Crea nuova campagna."""
    db = DB()
    try:
        db.acquire(pool)
        validated = campagna_model.CampagnaInput(**data)
        new_id = campagna_repository.insert(db, validated.model_dump())
        row = campagna_repository.select(db, new_id)
        output = campagna_model.CampagnaOutput(**dict(row))
        return campagna_model.response(False, None, output.model_dump())
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()


async def update(pool: DBConnPool, id: int, data: Dict[str, Any]) -> dict:
    """Aggiorna campagna esistente."""
    db = DB()
    try:
        db.acquire(pool)
        row = campagna_repository.select(db, id)
        if not row:
            return campagna_model.response(True, "Campagna non trovata", None)
        validated = campagna_model.CampagnaInput(**data)
        campagna_repository.update(db, id, validated.model_dump())
        row = campagna_repository.select(db, id)
        output = campagna_model.CampagnaOutput(**dict(row))
        return campagna_model.response(False, None, output.model_dump())
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()


async def delete(pool: DBConnPool, id: int) -> dict:
    """Elimina campagna."""
    db = DB()
    try:
        db.acquire(pool)
        row = campagna_repository.select(db, id)
        if not row:
            return campagna_model.response(True, "Campagna non trovata", None)
        campagna_repository.delete(db, id)
        return campagna_model.response(False, None, {"deleted": id})
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()


async def get_liste(pool: DBConnPool, campagna_id: int) -> dict:
    """Recupera liste di una campagna."""
    db = DB()
    try:
        db.acquire(pool)
        row = campagna_repository.select(db, campagna_id)
        if not row:
            return campagna_model.response(True, "Campagna non trovata", None)
        rows = lista_repository.select_by_campagna(db, campagna_id)
        items = [dict(row) for row in rows]
        output = lista_model.ListaListOutput(items=items, total=len(items))
        return campagna_model.response(False, None, output.model_dump())
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()


async def add_liste(pool: DBConnPool, campagna_id: int, lista_ids: List[int]) -> dict:
    """Aggiunge liste a una campagna."""
    db = DB()
    try:
        db.acquire(pool)
        row = campagna_repository.select(db, campagna_id)
        if not row:
            return campagna_model.response(True, "Campagna non trovata", None)
        count = campagna_repository.add_liste(db, campagna_id, lista_ids)
        return campagna_model.response(False, None, {"added": count})
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()


async def remove_liste(pool: DBConnPool, campagna_id: int, lista_ids: List[int]) -> dict:
    """Rimuove liste da una campagna."""
    db = DB()
    try:
        db.acquire(pool)
        row = campagna_repository.select(db, campagna_id)
        if not row:
            return campagna_model.response(True, "Campagna non trovata", None)
        count = campagna_repository.remove_liste(db, campagna_id, lista_ids)
        return campagna_model.response(False, None, {"removed": count})
    except Exception as e:
        return campagna_model.response(True, str(e), None)
    finally:
        db.release()
