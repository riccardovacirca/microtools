"""Service per entita Lista."""
from typing import Dict, Any, List
from api.utils.DB import DB
from api.utils.DBConnPool import DBConnPool
from ..models import lista_model, contatto_model
from ..repositories import lista_repository, contatto_repository


async def get_all(pool: DBConnPool) -> dict:
    """Recupera tutte le liste."""
    db = DB()
    try:
        db.acquire(pool)
        rows = lista_repository.select_all(db)
        items = [dict(row) for row in rows]
        output = lista_model.ListaListOutput(items=items, total=len(items))
        return lista_model.response(False, None, output.model_dump())
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()


async def get(pool: DBConnPool, id: int) -> dict:
    """Recupera lista by ID."""
    db = DB()
    try:
        db.acquire(pool)
        row = lista_repository.select(db, id)
        if not row:
            return lista_model.response(True, "Lista non trovata", None)
        output = lista_model.ListaOutput(**dict(row))
        return lista_model.response(False, None, output.model_dump())
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()


async def create(pool: DBConnPool, data: Dict[str, Any]) -> dict:
    """Crea nuova lista."""
    db = DB()
    try:
        db.acquire(pool)
        validated = lista_model.ListaInput(**data)
        new_id = lista_repository.insert(db, validated.model_dump())
        row = lista_repository.select(db, new_id)
        output = lista_model.ListaOutput(**dict(row))
        return lista_model.response(False, None, output.model_dump())
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()


async def update(pool: DBConnPool, id: int, data: Dict[str, Any]) -> dict:
    """Aggiorna lista esistente."""
    db = DB()
    try:
        db.acquire(pool)
        row = lista_repository.select(db, id)
        if not row:
            return lista_model.response(True, "Lista non trovata", None)
        validated = lista_model.ListaInput(**data)
        lista_repository.update(db, id, validated.model_dump())
        row = lista_repository.select(db, id)
        output = lista_model.ListaOutput(**dict(row))
        return lista_model.response(False, None, output.model_dump())
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()


async def delete(pool: DBConnPool, id: int) -> dict:
    """Elimina lista."""
    db = DB()
    try:
        db.acquire(pool)
        row = lista_repository.select(db, id)
        if not row:
            return lista_model.response(True, "Lista non trovata", None)
        lista_repository.delete(db, id)
        return lista_model.response(False, None, {"deleted": id})
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()


async def get_contatti(pool: DBConnPool, lista_id: int) -> dict:
    """Recupera contatti di una lista."""
    db = DB()
    try:
        db.acquire(pool)
        row = lista_repository.select(db, lista_id)
        if not row:
            return lista_model.response(True, "Lista non trovata", None)
        rows = contatto_repository.select_by_lista(db, lista_id)
        items = [dict(row) for row in rows]
        output = contatto_model.ContattoListOutput(items=items, total=len(items))
        return lista_model.response(False, None, output.model_dump())
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()


async def add_contatti(pool: DBConnPool, lista_id: int, contatto_ids: List[int]) -> dict:
    """Aggiunge contatti a una lista."""
    db = DB()
    try:
        db.acquire(pool)
        row = lista_repository.select(db, lista_id)
        if not row:
            return lista_model.response(True, "Lista non trovata", None)
        count = lista_repository.add_contatti(db, lista_id, contatto_ids)
        return lista_model.response(False, None, {"added": count})
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()


async def remove_contatti(pool: DBConnPool, lista_id: int, contatto_ids: List[int]) -> dict:
    """Rimuove contatti da una lista."""
    db = DB()
    try:
        db.acquire(pool)
        row = lista_repository.select(db, lista_id)
        if not row:
            return lista_model.response(True, "Lista non trovata", None)
        count = lista_repository.remove_contatti(db, lista_id, contatto_ids)
        return lista_model.response(False, None, {"removed": count})
    except Exception as e:
        return lista_model.response(True, str(e), None)
    finally:
        db.release()
