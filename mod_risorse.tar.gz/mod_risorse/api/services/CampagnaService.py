from typing import Dict, Any
from pydantic import ValidationError
from ..models import CampagnaModel
from ..models import ResponseModel
from ..repositories import CampagnaRepository
from ...utils.DB import DB
from ...utils.DBConnPool import DBConnPool

def _getDb(pool: DBConnPool) -> DB:
    """Crea e configura connessione DB."""
    db = DB()
    db.acquire(pool)
    return db

async def getAll(pool: DBConnPool) -> Dict[str, Any]:
    """Recupera tutte le campagne."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        rows = CampagnaRepository.getAll(db)
        out = []
        for row in rows:
            out.append(CampagnaModel.get(row))
    except ValidationError:
        err = True
        log = "Campagna data validation failed"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getById(pool: DBConnPool, id: int) -> Dict[str, Any]:
    """Recupera campagna per id."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        row = CampagnaRepository.getById(db, id)
        if row:
            out = CampagnaModel.get(row)
        else:
            err = True
            log = "Campagna not found"
    except ValidationError:
        err = True
        log = "Campagna data validation failed"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getActive(pool: DBConnPool) -> Dict[str, Any]:
    """Recupera campagne attive."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        rows = CampagnaRepository.getActive(db)
        out = []
        for row in rows:
            out.append(CampagnaModel.get(row))
    except ValidationError:
        err = True
        log = "Campagna data validation failed"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def create(pool: DBConnPool, data: Dict[str, Any]) -> Dict[str, Any]:
    """Crea nuova campagna."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        validated = CampagnaModel.getCreate(data)
        db = _getDb(pool)
        result = CampagnaRepository.create(db, validated)
        if result is not None and result > 0:
            out = {"created": True, "rows": result}
        else:
            err = True
            log = "Failed to create campagna"
    except ValidationError as e:
        err = True
        log = str(e)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def update(pool: DBConnPool, id: int, data: Dict[str, Any]) -> Dict[str, Any]:
    """Aggiorna campagna esistente."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        validated = CampagnaModel.getUpdate(data)
        db = _getDb(pool)
        existing = CampagnaRepository.getById(db, id)
        if not existing:
            err = True
            log = "Campagna not found"
        else:
            result = CampagnaRepository.update(db, id, validated)
            if result is not None:
                out = {"updated": True, "rows": result}
            else:
                err = True
                log = "Failed to update campagna"
    except ValidationError as e:
        err = True
        log = str(e)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def delete(pool: DBConnPool, id: int) -> Dict[str, Any]:
    """Elimina campagna."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        existing = CampagnaRepository.getById(db, id)
        if not existing:
            err = True
            log = "Campagna not found"
        else:
            result = CampagnaRepository.delete(db, id)
            if result is not None:
                out = {"deleted": True, "rows": result}
            else:
                err = True
                log = "Failed to delete campagna"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getListe(pool: DBConnPool, campagnaId: int) -> Dict[str, Any]:
    """Recupera liste di una campagna."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        out = CampagnaRepository.getListe(db, campagnaId)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def addLista(pool: DBConnPool, campagnaId: int, listaId: int) -> Dict[str, Any]:
    """Aggiunge lista a campagna."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        result = CampagnaRepository.addLista(db, campagnaId, listaId)
        if result is not None:
            out = {"added": True}
        else:
            err = True
            log = "Failed to add lista to campagna"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def removeLista(pool: DBConnPool, campagnaId: int, listaId: int) -> Dict[str, Any]:
    """Rimuove lista da campagna."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        result = CampagnaRepository.removeLista(db, campagnaId, listaId)
        if result is not None:
            out = {"removed": True}
        else:
            err = True
            log = "Failed to remove lista from campagna"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)
