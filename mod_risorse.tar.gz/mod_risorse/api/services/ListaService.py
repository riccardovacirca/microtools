from typing import Dict, Any
from pydantic import ValidationError
from ..models import ListaModel
from ..models import ResponseModel
from ..repositories import ListaRepository
from ...utils.DB import DB
from ...utils.DBConnPool import DBConnPool

def _getDb(pool: DBConnPool) -> DB:
    """Crea e configura connessione DB."""
    db = DB()
    db.acquire(pool)
    return db

async def getAll(pool: DBConnPool) -> Dict[str, Any]:
    """Recupera tutte le liste."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        rows = ListaRepository.getAll(db)
        out = []
        for row in rows:
            out.append(ListaModel.get(row))
    except ValidationError:
        err = True
        log = "Lista data validation failed"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getById(pool: DBConnPool, id: int) -> Dict[str, Any]:
    """Recupera lista per id."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        row = ListaRepository.getById(db, id)
        if row:
            out = ListaModel.get(row)
        else:
            err = True
            log = "Lista not found"
    except ValidationError:
        err = True
        log = "Lista data validation failed"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def create(pool: DBConnPool, data: Dict[str, Any]) -> Dict[str, Any]:
    """Crea nuova lista."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        validated = ListaModel.getCreate(data)
        db = _getDb(pool)
        result = ListaRepository.create(db, validated)
        if result is not None and result > 0:
            out = {"created": True, "rows": result}
        else:
            err = True
            log = "Failed to create lista"
    except ValidationError as e:
        err = True
        log = str(e)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def update(pool: DBConnPool, id: int, data: Dict[str, Any]) -> Dict[str, Any]:
    """Aggiorna lista esistente."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        validated = ListaModel.getUpdate(data)
        db = _getDb(pool)
        existing = ListaRepository.getById(db, id)
        if not existing:
            err = True
            log = "Lista not found"
        else:
            result = ListaRepository.update(db, id, validated)
            if result is not None:
                out = {"updated": True, "rows": result}
            else:
                err = True
                log = "Failed to update lista"
    except ValidationError as e:
        err = True
        log = str(e)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def delete(pool: DBConnPool, id: int) -> Dict[str, Any]:
    """Elimina lista."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        existing = ListaRepository.getById(db, id)
        if not existing:
            err = True
            log = "Lista not found"
        else:
            result = ListaRepository.delete(db, id)
            if result is not None:
                out = {"deleted": True, "rows": result}
            else:
                err = True
                log = "Failed to delete lista"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getContatti(pool: DBConnPool, listaId: int) -> Dict[str, Any]:
    """Recupera contatti di una lista."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        out = ListaRepository.getContatti(db, listaId)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getCampagne(pool: DBConnPool, listaId: int) -> Dict[str, Any]:
    """Recupera campagne di una lista."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        out = ListaRepository.getCampagne(db, listaId)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def addToCampagna(pool: DBConnPool, listaId: int, campagnaId: int) -> Dict[str, Any]:
    """Aggiunge lista a campagna."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        result = ListaRepository.addToCampagna(db, listaId, campagnaId)
        if result is not None:
            out = {"added": True}
        else:
            err = True
            log = "Failed to add lista to campagna"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def removeFromCampagna(pool: DBConnPool, listaId: int, campagnaId: int) -> Dict[str, Any]:
    """Rimuove lista da campagna."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        result = ListaRepository.removeFromCampagna(db, listaId, campagnaId)
        if result is not None:
            out = {"removed": True}
        else:
            err = True
            log = "Failed to remove lista from campagna"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)
