"""Service per entita Contatto."""
from typing import Dict, Any
from api.utils.DB import DB
from api.utils.DBConnPool import DBConnPool
from ..models import contatto_model
from ..repositories import contatto_repository


async def get_all(pool: DBConnPool) -> dict:
    """Recupera tutti i contatti."""
    db = DB()
    try:
        db.acquire(pool)
        rows = contatto_repository.select_all(db)
        items = [dict(row) for row in rows]
        output = contatto_model.ContattoListOutput(items=items, total=len(items))
        return contatto_model.response(False, None, output.model_dump())
    except Exception as e:
        return contatto_model.response(True, str(e), None)
    finally:
        db.release()


async def get(pool: DBConnPool, id: int) -> dict:
    """Recupera contatto by ID."""
    db = DB()
    try:
        db.acquire(pool)
        row = contatto_repository.select(db, id)
        if not row:
            return contatto_model.response(True, "Contatto non trovato", None)
        output = contatto_model.ContattoOutput(**dict(row))
        return contatto_model.response(False, None, output.model_dump())
    except Exception as e:
        return contatto_model.response(True, str(e), None)
    finally:
        db.release()


async def create(pool: DBConnPool, data: Dict[str, Any]) -> dict:
    """Crea nuovo contatto."""
    db = DB()
    try:
        db.acquire(pool)
        validated = contatto_model.ContattoInput(**data)
        new_id = contatto_repository.insert(db, validated.model_dump())
        row = contatto_repository.select(db, new_id)
        output = contatto_model.ContattoOutput(**dict(row))
        return contatto_model.response(False, None, output.model_dump())
    except Exception as e:
        return contatto_model.response(True, str(e), None)
    finally:
        db.release()


async def update(pool: DBConnPool, id: int, data: Dict[str, Any]) -> dict:
    """Aggiorna contatto esistente."""
    db = DB()
    try:
        db.acquire(pool)
        row = contatto_repository.select(db, id)
        if not row:
            return contatto_model.response(True, "Contatto non trovato", None)
        validated = contatto_model.ContattoInput(**data)
        contatto_repository.update(db, id, validated.model_dump())
        row = contatto_repository.select(db, id)
        output = contatto_model.ContattoOutput(**dict(row))
        return contatto_model.response(False, None, output.model_dump())
    except Exception as e:
        return contatto_model.response(True, str(e), None)
    finally:
        db.release()


async def delete(pool: DBConnPool, id: int) -> dict:
    """Elimina contatto."""
    db = DB()
    try:
        db.acquire(pool)
        row = contatto_repository.select(db, id)
        if not row:
            return contatto_model.response(True, "Contatto non trovato", None)
        contatto_repository.delete(db, id)
        return contatto_model.response(False, None, {"deleted": id})
    except Exception as e:
        return contatto_model.response(True, str(e), None)
    finally:
        db.release()
