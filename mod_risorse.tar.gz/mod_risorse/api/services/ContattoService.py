from typing import Dict, Any
from pydantic import ValidationError
from ..models import ContattoModel
from ..models import ResponseModel
from ..repositories import ContattoRepository
from ...utils.DB import DB
from ...utils.DBConnPool import DBConnPool

def _getDb(pool: DBConnPool) -> DB:
    """Crea e configura connessione DB."""
    db = DB()
    db.acquire(pool)
    return db

async def getAll(pool: DBConnPool) -> Dict[str, Any]:
    """Recupera tutti i contatti."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        rows = ContattoRepository.getAll(db)
        out = []
        for row in rows:
            out.append(ContattoModel.get(row))
    except ValidationError:
        err = True
        log = "Contatto data validation failed"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getById(pool: DBConnPool, id: int) -> Dict[str, Any]:
    """Recupera contatto per id."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        row = ContattoRepository.getById(db, id)
        if row:
            out = ContattoModel.get(row)
        else:
            err = True
            log = "Contatto not found"
    except ValidationError:
        err = True
        log = "Contatto data validation failed"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def create(pool: DBConnPool, data: Dict[str, Any]) -> Dict[str, Any]:
    """Crea nuovo contatto."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        validated = ContattoModel.getCreate(data)
        db = _getDb(pool)
        result = ContattoRepository.create(db, validated)
        if result is not None and result > 0:
            out = {"created": True, "rows": result}
        else:
            err = True
            log = "Failed to create contatto"
    except ValidationError as e:
        err = True
        log = str(e)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def update(pool: DBConnPool, id: int, data: Dict[str, Any]) -> Dict[str, Any]:
    """Aggiorna contatto esistente."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        validated = ContattoModel.getUpdate(data)
        db = _getDb(pool)
        existing = ContattoRepository.getById(db, id)
        if not existing:
            err = True
            log = "Contatto not found"
        else:
            result = ContattoRepository.update(db, id, validated)
            if result is not None:
                out = {"updated": True, "rows": result}
            else:
                err = True
                log = "Failed to update contatto"
    except ValidationError as e:
        err = True
        log = str(e)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def delete(pool: DBConnPool, id: int) -> Dict[str, Any]:
    """Elimina contatto."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        existing = ContattoRepository.getById(db, id)
        if not existing:
            err = True
            log = "Contatto not found"
        else:
            result = ContattoRepository.delete(db, id)
            if result is not None:
                out = {"deleted": True, "rows": result}
            else:
                err = True
                log = "Failed to delete contatto"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def addToLista(pool: DBConnPool, contattoId: int, listaId: int) -> Dict[str, Any]:
    """Aggiunge contatto a lista."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        result = ContattoRepository.addToLista(db, contattoId, listaId)
        if result is not None:
            out = {"added": True}
        else:
            err = True
            log = "Failed to add contatto to lista"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def removeFromLista(pool: DBConnPool, contattoId: int, listaId: int) -> Dict[str, Any]:
    """Rimuove contatto da lista."""
    err = False
    log: str | None = None
    out: Dict[str, Any] | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        result = ContattoRepository.removeFromLista(db, contattoId, listaId)
        if result is not None:
            out = {"removed": True}
        else:
            err = True
            log = "Failed to remove contatto from lista"
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)

async def getListe(pool: DBConnPool, contattoId: int) -> Dict[str, Any]:
    """Recupera liste di un contatto."""
    err = False
    log: str | None = None
    out: list | None = None
    db: DB | None = None
    try:
        db = _getDb(pool)
        out = ContattoRepository.getListe(db, contattoId)
    except Exception as e:
        err = True
        log = str(e) or "Unknown error"
    finally:
        if db is not None:
            db.release()
    return ResponseModel.set(err, log, out)
