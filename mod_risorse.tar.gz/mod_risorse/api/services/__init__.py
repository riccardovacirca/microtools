"""Services per mod_risorse."""
