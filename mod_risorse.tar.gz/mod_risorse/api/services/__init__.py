"""Services per mod_risorse."""
from . import ContattoService
from . import ListaService
from . import CampagnaService
