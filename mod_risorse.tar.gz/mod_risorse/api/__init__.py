"""Modulo mod_risorse - Gestione risorse CRM."""
