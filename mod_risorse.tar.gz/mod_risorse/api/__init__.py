"""Modulo risorse CRM: contatti, liste, campagne."""
