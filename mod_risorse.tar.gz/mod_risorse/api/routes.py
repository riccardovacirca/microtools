from fastapi import APIRouter, Request
from typing import Dict, Any
from .services import ContattoService
from .services import ListaService
from .services import CampagnaService

router = APIRouter(prefix="/risorse", tags=["risorse"])

# ============================================================================
# CONTATTI
# ============================================================================

@router.get("/contatti")
async def getContatti(request: Request) -> Dict[str, Any]:
    """Recupera tutti i contatti."""
    pool = request.app.state.db_pool
    data = await ContattoService.getAll(pool)
    return data

@router.get("/contatti/{id}")
async def getContattoById(request: Request, id: int) -> Dict[str, Any]:
    """Recupera contatto per id."""
    pool = request.app.state.db_pool
    data = await ContattoService.getById(pool, id)
    return data

@router.post("/contatti")
async def createContatto(request: Request) -> Dict[str, Any]:
    """Crea nuovo contatto."""
    pool = request.app.state.db_pool
    body = await request.json()
    data = await ContattoService.create(pool, body)
    return data

@router.put("/contatti/{id}")
async def updateContatto(request: Request, id: int) -> Dict[str, Any]:
    """Aggiorna contatto esistente."""
    pool = request.app.state.db_pool
    body = await request.json()
    data = await ContattoService.update(pool, id, body)
    return data

@router.delete("/contatti/{id}")
async def deleteContatto(request: Request, id: int) -> Dict[str, Any]:
    """Elimina contatto."""
    pool = request.app.state.db_pool
    data = await ContattoService.delete(pool, id)
    return data

@router.get("/contatti/{id}/liste")
async def getContattoListe(request: Request, id: int) -> Dict[str, Any]:
    """Recupera liste di un contatto."""
    pool = request.app.state.db_pool
    data = await ContattoService.getListe(pool, id)
    return data

@router.post("/contatti/{contattoId}/liste/{listaId}")
async def addContattoToLista(request: Request, contattoId: int, listaId: int) -> Dict[str, Any]:
    """Aggiunge contatto a lista."""
    pool = request.app.state.db_pool
    data = await ContattoService.addToLista(pool, contattoId, listaId)
    return data

@router.delete("/contatti/{contattoId}/liste/{listaId}")
async def removeContattoFromLista(request: Request, contattoId: int, listaId: int) -> Dict[str, Any]:
    """Rimuove contatto da lista."""
    pool = request.app.state.db_pool
    data = await ContattoService.removeFromLista(pool, contattoId, listaId)
    return data

# ============================================================================
# LISTE
# ============================================================================

@router.get("/liste")
async def getListe(request: Request) -> Dict[str, Any]:
    """Recupera tutte le liste."""
    pool = request.app.state.db_pool
    data = await ListaService.getAll(pool)
    return data

@router.get("/liste/{id}")
async def getListaById(request: Request, id: int) -> Dict[str, Any]:
    """Recupera lista per id."""
    pool = request.app.state.db_pool
    data = await ListaService.getById(pool, id)
    return data

@router.post("/liste")
async def createLista(request: Request) -> Dict[str, Any]:
    """Crea nuova lista."""
    pool = request.app.state.db_pool
    body = await request.json()
    data = await ListaService.create(pool, body)
    return data

@router.put("/liste/{id}")
async def updateLista(request: Request, id: int) -> Dict[str, Any]:
    """Aggiorna lista esistente."""
    pool = request.app.state.db_pool
    body = await request.json()
    data = await ListaService.update(pool, id, body)
    return data

@router.delete("/liste/{id}")
async def deleteLista(request: Request, id: int) -> Dict[str, Any]:
    """Elimina lista."""
    pool = request.app.state.db_pool
    data = await ListaService.delete(pool, id)
    return data

@router.get("/liste/{id}/contatti")
async def getListaContatti(request: Request, id: int) -> Dict[str, Any]:
    """Recupera contatti di una lista."""
    pool = request.app.state.db_pool
    data = await ListaService.getContatti(pool, id)
    return data

@router.get("/liste/{id}/campagne")
async def getListaCampagne(request: Request, id: int) -> Dict[str, Any]:
    """Recupera campagne di una lista."""
    pool = request.app.state.db_pool
    data = await ListaService.getCampagne(pool, id)
    return data

@router.post("/liste/{listaId}/campagne/{campagnaId}")
async def addListaToCampagna(request: Request, listaId: int, campagnaId: int) -> Dict[str, Any]:
    """Aggiunge lista a campagna."""
    pool = request.app.state.db_pool
    data = await ListaService.addToCampagna(pool, listaId, campagnaId)
    return data

@router.delete("/liste/{listaId}/campagne/{campagnaId}")
async def removeListaFromCampagna(request: Request, listaId: int, campagnaId: int) -> Dict[str, Any]:
    """Rimuove lista da campagna."""
    pool = request.app.state.db_pool
    data = await ListaService.removeFromCampagna(pool, listaId, campagnaId)
    return data

# ============================================================================
# CAMPAGNE
# ============================================================================

@router.get("/campagne")
async def getCampagne(request: Request) -> Dict[str, Any]:
    """Recupera tutte le campagne."""
    pool = request.app.state.db_pool
    data = await CampagnaService.getAll(pool)
    return data

@router.get("/campagne/active")
async def getCampagneActive(request: Request) -> Dict[str, Any]:
    """Recupera campagne attive."""
    pool = request.app.state.db_pool
    data = await CampagnaService.getActive(pool)
    return data

@router.get("/campagne/{id}")
async def getCampagnaById(request: Request, id: int) -> Dict[str, Any]:
    """Recupera campagna per id."""
    pool = request.app.state.db_pool
    data = await CampagnaService.getById(pool, id)
    return data

@router.post("/campagne")
async def createCampagna(request: Request) -> Dict[str, Any]:
    """Crea nuova campagna."""
    pool = request.app.state.db_pool
    body = await request.json()
    data = await CampagnaService.create(pool, body)
    return data

@router.put("/campagne/{id}")
async def updateCampagna(request: Request, id: int) -> Dict[str, Any]:
    """Aggiorna campagna esistente."""
    pool = request.app.state.db_pool
    body = await request.json()
    data = await CampagnaService.update(pool, id, body)
    return data

@router.delete("/campagne/{id}")
async def deleteCampagna(request: Request, id: int) -> Dict[str, Any]:
    """Elimina campagna."""
    pool = request.app.state.db_pool
    data = await CampagnaService.delete(pool, id)
    return data

@router.get("/campagne/{id}/liste")
async def getCampagnaListe(request: Request, id: int) -> Dict[str, Any]:
    """Recupera liste di una campagna."""
    pool = request.app.state.db_pool
    data = await CampagnaService.getListe(pool, id)
    return data

@router.post("/campagne/{campagnaId}/liste/{listaId}")
async def addCampagnaLista(request: Request, campagnaId: int, listaId: int) -> Dict[str, Any]:
    """Aggiunge lista a campagna."""
    pool = request.app.state.db_pool
    data = await CampagnaService.addLista(pool, campagnaId, listaId)
    return data

@router.delete("/campagne/{campagnaId}/liste/{listaId}")
async def removeCampagnaLista(request: Request, campagnaId: int, listaId: int) -> Dict[str, Any]:
    """Rimuove lista da campagna."""
    pool = request.app.state.db_pool
    data = await CampagnaService.removeLista(pool, campagnaId, listaId)
    return data
