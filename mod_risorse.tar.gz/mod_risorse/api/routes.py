"""Routes per mod_risorse."""
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from api.utils.DBConnPool import DBConnPool
from .services import contatto_service, lista_service, campagna_service

router = APIRouter()

# Pool connessioni database (inizializzato esternamente)
pool: DBConnPool = None


def init_pool(db_pool: DBConnPool):
    """Inizializza pool connessioni."""
    global pool
    pool = db_pool


# === CONTATTI ===

@router.get("/api/risorse/contatti")
async def contatti_list():
    """Lista tutti i contatti."""
    data = await contatto_service.get_all(pool)
    if data["err"]:
        return JSONResponse(data, 503)
    return JSONResponse(data, 200)


@router.get("/api/risorse/contatti/{id}")
async def contatti_get(id: int):
    """Recupera contatto by ID."""
    data = await contatto_service.get(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovato" in data["log"] else 503)
    return JSONResponse(data, 200)


@router.post("/api/risorse/contatti")
async def contatti_create(request: Request):
    """Crea nuovo contatto."""
    body = await request.json()
    data = await contatto_service.create(pool, body)
    if data["err"]:
        return JSONResponse(data, 400)
    return JSONResponse(data, 201)


@router.put("/api/risorse/contatti/{id}")
async def contatti_update(id: int, request: Request):
    """Aggiorna contatto esistente."""
    body = await request.json()
    data = await contatto_service.update(pool, id, body)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovato" in data["log"] else 400)
    return JSONResponse(data, 200)


@router.delete("/api/risorse/contatti/{id}")
async def contatti_delete(id: int):
    """Elimina contatto."""
    data = await contatto_service.delete(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovato" in data["log"] else 503)
    return JSONResponse(data, 200)


# === LISTE ===

@router.get("/api/risorse/liste")
async def liste_list():
    """Lista tutte le liste."""
    data = await lista_service.get_all(pool)
    if data["err"]:
        return JSONResponse(data, 503)
    return JSONResponse(data, 200)


@router.get("/api/risorse/liste/{id}")
async def liste_get(id: int):
    """Recupera lista by ID."""
    data = await lista_service.get(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 503)
    return JSONResponse(data, 200)


@router.post("/api/risorse/liste")
async def liste_create(request: Request):
    """Crea nuova lista."""
    body = await request.json()
    data = await lista_service.create(pool, body)
    if data["err"]:
        return JSONResponse(data, 400)
    return JSONResponse(data, 201)


@router.put("/api/risorse/liste/{id}")
async def liste_update(id: int, request: Request):
    """Aggiorna lista esistente."""
    body = await request.json()
    data = await lista_service.update(pool, id, body)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 400)
    return JSONResponse(data, 200)


@router.delete("/api/risorse/liste/{id}")
async def liste_delete(id: int):
    """Elimina lista."""
    data = await lista_service.delete(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 503)
    return JSONResponse(data, 200)


@router.get("/api/risorse/liste/{id}/contatti")
async def liste_contatti_list(id: int):
    """Lista contatti di una lista."""
    data = await lista_service.get_contatti(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 503)
    return JSONResponse(data, 200)


@router.post("/api/risorse/liste/{id}/contatti")
async def liste_contatti_add(id: int, request: Request):
    """Aggiunge contatti a una lista."""
    body = await request.json()
    data = await lista_service.add_contatti(pool, id, body["contatto_ids"])
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 400)
    return JSONResponse(data, 200)


@router.delete("/api/risorse/liste/{id}/contatti")
async def liste_contatti_remove(id: int, request: Request):
    """Rimuove contatti da una lista."""
    body = await request.json()
    data = await lista_service.remove_contatti(pool, id, body["contatto_ids"])
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 400)
    return JSONResponse(data, 200)


# === CAMPAGNE ===

@router.get("/api/risorse/campagne")
async def campagne_list():
    """Lista tutte le campagne."""
    data = await campagna_service.get_all(pool)
    if data["err"]:
        return JSONResponse(data, 503)
    return JSONResponse(data, 200)


@router.get("/api/risorse/campagne/{id}")
async def campagne_get(id: int):
    """Recupera campagna by ID."""
    data = await campagna_service.get(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 503)
    return JSONResponse(data, 200)


@router.post("/api/risorse/campagne")
async def campagne_create(request: Request):
    """Crea nuova campagna."""
    body = await request.json()
    data = await campagna_service.create(pool, body)
    if data["err"]:
        return JSONResponse(data, 400)
    return JSONResponse(data, 201)


@router.put("/api/risorse/campagne/{id}")
async def campagne_update(id: int, request: Request):
    """Aggiorna campagna esistente."""
    body = await request.json()
    data = await campagna_service.update(pool, id, body)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 400)
    return JSONResponse(data, 200)


@router.delete("/api/risorse/campagne/{id}")
async def campagne_delete(id: int):
    """Elimina campagna."""
    data = await campagna_service.delete(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 503)
    return JSONResponse(data, 200)


@router.get("/api/risorse/campagne/{id}/liste")
async def campagne_liste_list(id: int):
    """Lista liste di una campagna."""
    data = await campagna_service.get_liste(pool, id)
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 503)
    return JSONResponse(data, 200)


@router.post("/api/risorse/campagne/{id}/liste")
async def campagne_liste_add(id: int, request: Request):
    """Aggiunge liste a una campagna."""
    body = await request.json()
    data = await campagna_service.add_liste(pool, id, body["lista_ids"])
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 400)
    return JSONResponse(data, 200)


@router.delete("/api/risorse/campagne/{id}/liste")
async def campagne_liste_remove(id: int, request: Request):
    """Rimuove liste da una campagna."""
    body = await request.json()
    data = await campagna_service.remove_liste(pool, id, body["lista_ids"])
    if data["err"]:
        return JSONResponse(data, 404 if "non trovata" in data["log"] else 400)
    return JSONResponse(data, 200)
