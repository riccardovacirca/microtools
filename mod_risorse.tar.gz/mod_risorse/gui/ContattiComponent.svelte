<script>
  let contatti = $state([]);
  let loading = $state(true);
  let error = $state(null);
  let showForm = $state(false);
  let editingId = $state(null);
  let formData = $state({
    nome: '',
    cognome: '',
    email: '',
    telefono: '',
    indirizzo: '',
    citta: '',
    cap: '',
    provincia: '',
    nazione: '',
    consenso: 0,
    stato: 0
  });

  async function loadContatti() {
    loading = true;
    error = null;
    try {
      const res = await fetch('/api/risorse/contatti');
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        contatti = data.out.items;
      }
    } catch (e) {
      error = e.message;
    } finally {
      loading = false;
    }
  }

  async function saveContatto() {
    try {
      const url = editingId
        ? `/api/risorse/contatti/${editingId}`
        : '/api/risorse/contatti';
      const method = editingId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        showForm = false;
        resetForm();
        await loadContatti();
      }
    } catch (e) {
      error = e.message;
    }
  }

  async function deleteContatto(id) {
    if (!confirm('Eliminare questo contatto?')) return;
    try {
      const res = await fetch(`/api/risorse/contatti/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        await loadContatti();
      }
    } catch (e) {
      error = e.message;
    }
  }

  function editContatto(contatto) {
    editingId = contatto.id;
    formData = { ...contatto };
    showForm = true;
  }

  function resetForm() {
    editingId = null;
    formData = {
      nome: '',
      cognome: '',
      email: '',
      telefono: '',
      indirizzo: '',
      citta: '',
      cap: '',
      provincia: '',
      nazione: '',
      consenso: 0,
      stato: 0
    };
  }

  function newContatto() {
    resetForm();
    showForm = true;
  }

  $effect(() => {
    loadContatti();
  });
</script>

<div class="contatti-component">
  <header>
    <h2>Contatti</h2>
    <button class="btn-primary" onclick={newContatto}>Nuovo Contatto</button>
  </header>

  {#if error}
    <div class="error">{error}</div>
  {/if}

  {#if showForm}
    <div class="form-overlay">
      <form onsubmit={(e) => { e.preventDefault(); saveContatto(); }}>
        <h3>{editingId ? 'Modifica' : 'Nuovo'} Contatto</h3>
        <div class="form-row">
          <input type="text" placeholder="Nome" bind:value={formData.nome} required />
          <input type="text" placeholder="Cognome" bind:value={formData.cognome} required />
        </div>
        <div class="form-row">
          <input type="email" placeholder="Email" bind:value={formData.email} required />
          <input type="tel" placeholder="Telefono" bind:value={formData.telefono} />
        </div>
        <div class="form-row">
          <input type="text" placeholder="Indirizzo" bind:value={formData.indirizzo} />
          <input type="text" placeholder="Citta" bind:value={formData.citta} />
        </div>
        <div class="form-row">
          <input type="text" placeholder="CAP" bind:value={formData.cap} />
          <input type="text" placeholder="Provincia" bind:value={formData.provincia} />
          <input type="text" placeholder="Nazione" bind:value={formData.nazione} />
        </div>
        <div class="form-row">
          <label>
            Consenso:
            <input type="number" bind:value={formData.consenso} min="0" />
          </label>
          <label>
            Stato:
            <input type="number" bind:value={formData.stato} min="0" />
          </label>
        </div>
        <div class="form-actions">
          <button type="button" onclick={() => { showForm = false; resetForm(); }}>Annulla</button>
          <button type="submit" class="btn-primary">Salva</button>
        </div>
      </form>
    </div>
  {/if}

  {#if loading}
    <p>Caricamento...</p>
  {:else if contatti.length === 0}
    <p>Nessun contatto presente.</p>
  {:else}
    <table>
      <thead>
        <tr>
          <th>Nome</th>
          <th>Cognome</th>
          <th>Email</th>
          <th>Telefono</th>
          <th>Stato</th>
          <th>Azioni</th>
        </tr>
      </thead>
      <tbody>
        {#each contatti as contatto}
          <tr>
            <td>{contatto.nome}</td>
            <td>{contatto.cognome}</td>
            <td>{contatto.email}</td>
            <td>{contatto.telefono || '-'}</td>
            <td>{contatto.stato}</td>
            <td>
              <button onclick={() => editContatto(contatto)}>Modifica</button>
              <button onclick={() => deleteContatto(contatto.id)}>Elimina</button>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
  {/if}
</div>

<style>
  .contatti-component header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
  }

  .error {
    background: #fee;
    color: #c00;
    padding: 0.5rem;
    border-radius: 4px;
    margin-bottom: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
  }

  th, td {
    padding: 0.5rem;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }

  .btn-primary {
    background: #007bff;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    cursor: pointer;
  }

  .form-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .form-overlay form {
    background: white;
    padding: 1.5rem;
    border-radius: 8px;
    min-width: 400px;
  }

  .form-row {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 0.5rem;
  }

  .form-row input {
    flex: 1;
    padding: 0.5rem;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.5rem;
    margin-top: 1rem;
  }
</style>
