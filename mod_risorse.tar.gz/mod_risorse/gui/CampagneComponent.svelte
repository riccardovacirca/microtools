<script>
  let campagne = $state([]);
  let loading = $state(true);
  let error = $state(null);
  let showForm = $state(false);
  let editingId = $state(null);
  let formData = $state({
    nome: '',
    descrizione: '',
    data_inizio: '',
    data_fine: '',
    stato: 0
  });

  async function loadCampagne() {
    loading = true;
    error = null;
    try {
      const res = await fetch('/api/risorse/campagne');
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        campagne = data.out.items;
      }
    } catch (e) {
      error = e.message;
    } finally {
      loading = false;
    }
  }

  async function saveCampagna() {
    try {
      const url = editingId
        ? `/api/risorse/campagne/${editingId}`
        : '/api/risorse/campagne';
      const method = editingId ? 'PUT' : 'POST';
      const payload = { ...formData };
      if (!payload.data_fine) {
        payload.data_fine = null;
      }
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        showForm = false;
        resetForm();
        await loadCampagne();
      }
    } catch (e) {
      error = e.message;
    }
  }

  async function deleteCampagna(id) {
    if (!confirm('Eliminare questa campagna?')) return;
    try {
      const res = await fetch(`/api/risorse/campagne/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        await loadCampagne();
      }
    } catch (e) {
      error = e.message;
    }
  }

  function editCampagna(campagna) {
    editingId = campagna.id;
    formData = {
      nome: campagna.nome,
      descrizione: campagna.descrizione || '',
      data_inizio: campagna.data_inizio,
      data_fine: campagna.data_fine || '',
      stato: campagna.stato
    };
    showForm = true;
  }

  function resetForm() {
    editingId = null;
    formData = {
      nome: '',
      descrizione: '',
      data_inizio: '',
      data_fine: '',
      stato: 0
    };
  }

  function newCampagna() {
    resetForm();
    showForm = true;
  }

  $effect(() => {
    loadCampagne();
  });
</script>

<div class="campagne-component">
  <header>
    <h2>Campagne</h2>
    <button class="btn-primary" onclick={newCampagna}>Nuova Campagna</button>
  </header>

  {#if error}
    <div class="error">{error}</div>
  {/if}

  {#if showForm}
    <div class="form-overlay">
      <form onsubmit={(e) => { e.preventDefault(); saveCampagna(); }}>
        <h3>{editingId ? 'Modifica' : 'Nuova'} Campagna</h3>
        <div class="form-row">
          <input type="text" placeholder="Nome" bind:value={formData.nome} required />
        </div>
        <div class="form-row">
          <textarea placeholder="Descrizione" bind:value={formData.descrizione}></textarea>
        </div>
        <div class="form-row">
          <label>
            Data Inizio:
            <input type="date" bind:value={formData.data_inizio} required />
          </label>
          <label>
            Data Fine:
            <input type="date" bind:value={formData.data_fine} />
          </label>
        </div>
        <div class="form-row">
          <label>
            Stato:
            <input type="number" bind:value={formData.stato} min="0" />
          </label>
        </div>
        <div class="form-actions">
          <button type="button" onclick={() => { showForm = false; resetForm(); }}>Annulla</button>
          <button type="submit" class="btn-primary">Salva</button>
        </div>
      </form>
    </div>
  {/if}

  {#if loading}
    <p>Caricamento...</p>
  {:else if campagne.length === 0}
    <p>Nessuna campagna presente.</p>
  {:else}
    <table>
      <thead>
        <tr>
          <th>Nome</th>
          <th>Inizio</th>
          <th>Fine</th>
          <th>Liste</th>
          <th>Stato</th>
          <th>Azioni</th>
        </tr>
      </thead>
      <tbody>
        {#each campagne as campagna}
          <tr>
            <td>{campagna.nome}</td>
            <td>{campagna.data_inizio}</td>
            <td>{campagna.data_fine || '-'}</td>
            <td>{campagna.liste_count}</td>
            <td>{campagna.stato}</td>
            <td>
              <button onclick={() => editCampagna(campagna)}>Modifica</button>
              <button onclick={() => deleteCampagna(campagna.id)}>Elimina</button>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
  {/if}
</div>

<style>
  .campagne-component header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
  }

  .error {
    background: #fee;
    color: #c00;
    padding: 0.5rem;
    border-radius: 4px;
    margin-bottom: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
  }

  th, td {
    padding: 0.5rem;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }

  .btn-primary {
    background: #007bff;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    cursor: pointer;
  }

  .form-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .form-overlay form {
    background: white;
    padding: 1.5rem;
    border-radius: 8px;
    min-width: 400px;
  }

  .form-row {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 0.5rem;
  }

  .form-row input, .form-row textarea {
    flex: 1;
    padding: 0.5rem;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .form-row textarea {
    min-height: 80px;
    resize: vertical;
  }

  .form-row label {
    display: flex;
    flex-direction: column;
    flex: 1;
  }

  .form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.5rem;
    margin-top: 1rem;
  }
</style>
