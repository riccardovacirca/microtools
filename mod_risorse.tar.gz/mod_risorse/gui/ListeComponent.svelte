<script>
  let liste = $state([]);
  let loading = $state(true);
  let error = $state(null);
  let showForm = $state(false);
  let editingId = $state(null);
  let formData = $state({
    nome: '',
    descrizione: '',
    consenso_richiesto: 0,
    stato: 0
  });

  async function loadListe() {
    loading = true;
    error = null;
    try {
      const res = await fetch('/api/risorse/liste');
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        liste = data.out.items;
      }
    } catch (e) {
      error = e.message;
    } finally {
      loading = false;
    }
  }

  async function saveLista() {
    try {
      const url = editingId
        ? `/api/risorse/liste/${editingId}`
        : '/api/risorse/liste';
      const method = editingId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        showForm = false;
        resetForm();
        await loadListe();
      }
    } catch (e) {
      error = e.message;
    }
  }

  async function deleteLista(id) {
    if (!confirm('Eliminare questa lista?')) return;
    try {
      const res = await fetch(`/api/risorse/liste/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.err) {
        error = data.log;
      } else {
        await loadListe();
      }
    } catch (e) {
      error = e.message;
    }
  }

  function editLista(lista) {
    editingId = lista.id;
    formData = {
      nome: lista.nome,
      descrizione: lista.descrizione || '',
      consenso_richiesto: lista.consenso_richiesto,
      stato: lista.stato
    };
    showForm = true;
  }

  function resetForm() {
    editingId = null;
    formData = {
      nome: '',
      descrizione: '',
      consenso_richiesto: 0,
      stato: 0
    };
  }

  function newLista() {
    resetForm();
    showForm = true;
  }

  $effect(() => {
    loadListe();
  });
</script>

<div class="liste-component">
  <header>
    <h2>Liste</h2>
    <button class="btn-primary" onclick={newLista}>Nuova Lista</button>
  </header>

  {#if error}
    <div class="error">{error}</div>
  {/if}

  {#if showForm}
    <div class="form-overlay">
      <form onsubmit={(e) => { e.preventDefault(); saveLista(); }}>
        <h3>{editingId ? 'Modifica' : 'Nuova'} Lista</h3>
        <div class="form-row">
          <input type="text" placeholder="Nome" bind:value={formData.nome} required />
        </div>
        <div class="form-row">
          <textarea placeholder="Descrizione" bind:value={formData.descrizione}></textarea>
        </div>
        <div class="form-row">
          <label>
            Consenso Richiesto:
            <input type="number" bind:value={formData.consenso_richiesto} min="0" />
          </label>
          <label>
            Stato:
            <input type="number" bind:value={formData.stato} min="0" />
          </label>
        </div>
        <div class="form-actions">
          <button type="button" onclick={() => { showForm = false; resetForm(); }}>Annulla</button>
          <button type="submit" class="btn-primary">Salva</button>
        </div>
      </form>
    </div>
  {/if}

  {#if loading}
    <p>Caricamento...</p>
  {:else if liste.length === 0}
    <p>Nessuna lista presente.</p>
  {:else}
    <table>
      <thead>
        <tr>
          <th>Nome</th>
          <th>Descrizione</th>
          <th>Contatti</th>
          <th>Stato</th>
          <th>Azioni</th>
        </tr>
      </thead>
      <tbody>
        {#each liste as lista}
          <tr>
            <td>{lista.nome}</td>
            <td>{lista.descrizione || '-'}</td>
            <td>{lista.contatti_count}</td>
            <td>{lista.stato}</td>
            <td>
              <button onclick={() => editLista(lista)}>Modifica</button>
              <button onclick={() => deleteLista(lista.id)}>Elimina</button>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
  {/if}
</div>

<style>
  .liste-component header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
  }

  .error {
    background: #fee;
    color: #c00;
    padding: 0.5rem;
    border-radius: 4px;
    margin-bottom: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
  }

  th, td {
    padding: 0.5rem;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }

  .btn-primary {
    background: #007bff;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    cursor: pointer;
  }

  .form-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .form-overlay form {
    background: white;
    padding: 1.5rem;
    border-radius: 8px;
    min-width: 400px;
  }

  .form-row {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 0.5rem;
  }

  .form-row input, .form-row textarea {
    flex: 1;
    padding: 0.5rem;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .form-row textarea {
    min-height: 80px;
    resize: vertical;
  }

  .form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.5rem;
    margin-top: 1rem;
  }
</style>
