<script>
  let currentView = $state('contatti');
</script>

<div class="mod-risorse">
  <nav class="nav-tabs">
    <button
      class:active={currentView === 'contatti'}
      onclick={() => currentView = 'contatti'}
    >
      Contatti
    </button>
    <button
      class:active={currentView === 'liste'}
      onclick={() => currentView = 'liste'}
    >
      Liste
    </button>
    <button
      class:active={currentView === 'campagne'}
      onclick={() => currentView = 'campagne'}
    >
      Campagne
    </button>
  </nav>

  <main class="content">
    {#if currentView === 'contatti'}
      {#await import('./ContattiComponent.svelte') then { default: ContattiComponent }}
        <ContattiComponent />
      {/await}
    {:else if currentView === 'liste'}
      {#await import('./ListeComponent.svelte') then { default: ListeComponent }}
        <ListeComponent />
      {/await}
    {:else if currentView === 'campagne'}
      {#await import('./CampagneComponent.svelte') then { default: CampagneComponent }}
        <CampagneComponent />
      {/await}
    {/if}
  </main>
</div>

<style>
  .mod-risorse {
    padding: 1rem;
  }

  .nav-tabs {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1rem;
    border-bottom: 1px solid #ddd;
    padding-bottom: 0.5rem;
  }

  .nav-tabs button {
    padding: 0.5rem 1rem;
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 4px 4px 0 0;
  }

  .nav-tabs button:hover {
    background: #f0f0f0;
  }

  .nav-tabs button.active {
    background: #007bff;
    color: white;
  }

  .content {
    padding: 1rem 0;
  }
</style>
